package java8lambdabasics;

public interface Greeting {
	
	public void perform();
	
}
