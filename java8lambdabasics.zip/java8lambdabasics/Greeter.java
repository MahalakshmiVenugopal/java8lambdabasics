package java8lambdabasics;

public class Greeter {
	
	public void greet(Greeting greeting) {
		greeting.perform();
	}

	public static void main(String[] args) {

		Greeter greeter = new Greeter();
		HelloWorldGreeting hello = new HelloWorldGreeting();
		greeter.greet(hello);
		
		
		FunctionType<void, void>myLambdafunction = () -> System.out.println("HelloWord");
	}

}
